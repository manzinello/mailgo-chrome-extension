# 💌 mailgo Chrome extension

Official mailgo Chrome extension

https://chrome.google.com/webstore/detail/mailgo/kljnooagpdphdgjnmjhenkganebccejm
